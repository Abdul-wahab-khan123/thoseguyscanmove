<?php

$locAddress = "5005 Texas St #301, San Diego, CA 92108, United States";
$locEmail = "info@medicalcarebilling.com";
$locNumber = "(619) 393-5052" ;

$socialLinks = '<ul>
                <li><a href="https://www.facebook.com/medicalcarebilling" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                <li><a href="https://www.instagram.com/medicalcarebilling" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                <li><a href="https://www.pinterest.com/medicalcarebillingus" target="_blank"><i class="fa-brands fa-pinterest"></i></a></li>
                <li><a href="https://www.linkedin.com/company/medical-care-billing" target="_blank"><i class="fa-brands fa-linkedin"></i></a></li>
                </ul>';
?>